#!/usr/bin/env bash

cp .circleci/chapters/config_3_setup.yml .circleci/config.yml
cp .circleci/chapters/config_3_continue.yml .circleci/continue-config.yml