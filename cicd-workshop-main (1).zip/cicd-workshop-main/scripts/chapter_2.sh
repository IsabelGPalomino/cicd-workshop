#!/usr/bin/env bash

cp .circleci/chapters/config_2.yml .circleci/config.yml
rm -f .circleci/continue-config.yml
