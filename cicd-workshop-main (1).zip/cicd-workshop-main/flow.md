
Create a basic pipeline that runs your tests each time you commit some code
Install dependencies
Run a test
Record test results
Debug failed pipeline
Cache dependencies (manually)

Implement security scan
Use orb to install dependencies
Set up environment variables
Set up contexts & user groups
Build image (docker)
Deploy app (heroku prod)


Nightly build (deploy)
Split tests to run faster
Deploy to multiple environments (multiple apps)
Access control using groups
Approval job to continue

Setup workflow to split behaviour



